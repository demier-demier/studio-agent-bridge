Original Industrial AI Robotics Lab, source-bound cart revision.
Open scene-baseline.blend and scene-edited.blend in Blender 5.2 or newer. Packed textures are included in each file.
All 28 diagnostics cart objects moved +0.25 metres on X. The script requests translation only. Measurements cover those positions, mesh counts and adapter reopen invariants, not complete mesh data or every non-cart transform.
Both download copies were sanitized and resaved through native path properties. Their file hashes differ from their raw inputs. The original input source is separately preserved and identified in evidence.json. This is a visual demonstration.
