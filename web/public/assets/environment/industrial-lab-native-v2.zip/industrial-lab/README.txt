Industrial AI Laboratory — version 2 publication copies

Open scene-day.blend or scene-night.blend in Blender. Packed textures are included.
These scenes were sanitized through native RNA path properties, saved, independently reopened, and compared using explicit current-frame fingerprints. They are new publication copies with new file hashes, not byte-identical historical originals.
FBX path metadata was rewritten through Blender's official codec. All typed numeric arrays and non-path properties were preserved and the complete target was built and freshly inspected in a new Unreal project. No new image or renderer-equivalence claim is made.

publication.json contains source-to-publication hashes, measured comparisons and limitations. evidence.json is preserved byte-for-byte historical evidence; its original native and transfer hashes describe those earlier inputs. manifest.json describes the actual members of this v2 archive.
The bundled scripts are preserved historical source, including the older sanitizer. For current sanitation and publication use examples/publication_safety/README.md and sanitize_scene.py in the repository. Do not treat the historical sanitizer alone as a publication gate.
https://github.com/demier-demier/studio-agent-bridge/tree/main/examples/publication_safety
