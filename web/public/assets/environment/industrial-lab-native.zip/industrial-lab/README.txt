Original Industrial AI Laboratory — Studio Agent Bridge

Open scene-day.blend or scene-night.blend in Blender. Textures are packed.
The transfer/ directory contains a versioned scene manifest, local FBX meshes
and PBR textures for the Studio Agent Bridge Unreal environment importer.
The GLB is an evaluated visualization mesh, not the editable Blender source.
Reproduction and chat instructions:
https://github.com/demier-demier/studio-agent-bridge/tree/main/examples/environments/industrial_lab
Read evidence.json for observed checks and transfer limitations.
Original procedural scene, scripts and textures by Bernardo Demier; MIT.
Native applications and their licenses are separate.
