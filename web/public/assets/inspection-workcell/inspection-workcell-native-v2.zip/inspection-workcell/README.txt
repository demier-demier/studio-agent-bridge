Inspection workcell utility revision

Open scene.blend in Blender. Six cable curves remain editable. The transfer folder contains static FBX meshes, textures and a hash-bound environment manifest for Studio Agent Bridge. Native Unreal project files are not bundled; reproduce import using the public example. This original synthetic scene is a visual environment, not a functional inspection cell or safety-certified design.

Source and reproduction: https://github.com/demier-demier/studio-agent-bridge/tree/main/examples/inspection_workcell
